import React from 'react';
import { Dimensions, StyleSheet, View } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { Container, Header, Content, Form, Item, Input, Label } from 'native-base'
import InnerBtn from '../../Components/Innerbtn';


const CustomerDetails = (props) => {
    return (
        <ScrollView style= {styles.container}>
        <View style= {styles.biggerContainer}>
        <View style= {styles.flexContainer}>
            <View style= {{width: '70%'}}>
                <Form>
                <Item placeholderLabel= {styles.labelField} floatingLabel>
                <Label>Email Address</Label>
                <Input style= {styles.pickerField} />
                </Item>
                </Form>
            </View>
            <View style= {{width: '30%'}}>
            <InnerBtn onPress= {() => props.navigation.navigate('Success')} color= "white" bg= "#FDB813" text= "Submit" />
            </View>

        </View>
        </View>

        </ScrollView>

    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    flexContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center'
    },
    biggerContainer: {
        // backgroundColor: 'yellow',
        justifyContent: 'center',
        marginHorizontal: 25,
        height: Dimensions.get('window').height/1.3
    },
    labelField: {
        // backgroundColor: 'red'
        
    }
});

export default CustomerDetails
