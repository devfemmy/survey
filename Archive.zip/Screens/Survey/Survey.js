import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import InnerBtn from '../../Components/Innerbtn';
import OptionCard from '../../Components/OptionsCard';


const Survey = (props) => {
    let options = [
        {
            "id": 1,
            "option_group_id": "1",
            "icon": 'https://imghub.io/i/3RSm9',
            "name": "Excellent",
            "created_at": "2020-08-26T07:29:19.000000Z",
            "updated_at": null
        },
        {
            "id": 2,
            "option_group_id": "1",
            "icon": 'https://imghub.io/i/3RIvr',
            "name": "Satisfied",
            "created_at": "2020-08-26T07:29:19.000000Z",
            "updated_at": null
        },
        {
            "id": 3,
            "option_group_id": "1",
            "icon": 'https://imghub.io/i/3RZT6',
            "name": "Average",
            "created_at": "2020-08-26T07:29:19.000000Z",
            "updated_at": null
        },
        {
            "id": 4,
            "option_group_id": "1",
            "icon": 'https://imghub.io/i/3RoA1',
            "name": "Unsatisfied",
            "created_at": "2020-08-26T07:29:19.000000Z",
            "updated_at": null
        },
        {
            "id": 5,
            "option_group_id": "1",
            "icon": 'https://imghub.io/i/3R29J',
            "name": "Angry",
            "created_at": "2020-08-26T07:29:19.000000Z",
            "updated_at": null
        }
    ]
    const PROP = options
    return (
        <ScrollView style= {styles.container}>
           <View style= {styles.flexContainer}>
            <Text style= {styles.textStyle}>
            How was your experience today?
            </Text>
           <OptionCard 
                question_id={1} 
                pressed= {() => console.log('pressed')} 
                PROP={PROP} />
           </View>
           <View style= {{marginHorizontal: 320}}>
               <InnerBtn onPress= {() => props.navigation.navigate('Details')} color= "white" bg= "#FDB813" text= "Submit" />
           </View>
        </ScrollView>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FCFCFC'
    },
    textStyle: {
        fontSize: 22,
        textAlign: 'center',
        fontWeight: '500',
        marginVertical: 15

    },
    flexContainer: {
        // backgroundColor: 'red',
        // width: 250,
        // display: 'flex',
        // flexDirection: 'row',
        // flexWrap: 'wrap'
    }
});

export default Survey
