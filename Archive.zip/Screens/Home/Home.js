import React from 'react';
import { Dimensions, ImageBackground, StyleSheet, Text, View } from 'react-native';
import { ScrollView, TouchableOpacity } from 'react-native-gesture-handler';
import SurveyCard from '../../Components/SurveyCard';

const Home = (props) => {
    return (
        <ScrollView style= {styles.container}>
            <ImageBackground style= {styles.imageStyle} source= {require('../../assets/background.png')}>

            </ImageBackground>
            <View style= {styles.lowerContainer}>
                <TouchableOpacity onPress= {() => props.navigation.navigate('Survey', {name: 'Mobile App Survey'})}>
                    <SurveyCard>
                        <View style= {styles.textContainer}>
                            <Text style= {styles.textStyle}>
                                Mobile App Survey
                            </Text>
                            <View style= {styles.flexContainer}>
                                <Text style= {styles.textStyle2}>
                                    ENTER SURVEY
                                </Text>
                                
                            </View>
                        </View>
                    </SurveyCard>
                </TouchableOpacity>
                <TouchableOpacity  onPress= {() => props.navigation.navigate('Survey', {name: 'ATM Survey'})}>
                    <SurveyCard>
                        <View style= {styles.textContainer}>
                            <Text style= {styles.textStyle}>
                            ATM Survey
                            </Text>
                            <View style= {styles.flexContainer}>
                                <Text style= {styles.textStyle2}>
                                    ENTER SURVEY
                                </Text>
                                
                            </View>
                        </View>
                    </SurveyCard>
                </TouchableOpacity>
                <TouchableOpacity  onPress= {() => props.navigation.navigate('Survey', {name: 'Front Desk Survey'})}>
                    <SurveyCard>
                        <View style= {styles.textContainer}>
                            <Text style= {styles.textStyle}>
                            Front Desk Survey
                            </Text>
                            <View style= {styles.flexContainer}>
                                <Text style= {styles.textStyle2}>
                                    ENTER SURVEY
                                </Text>
                                
                            </View>
                        </View>
                    </SurveyCard>
                </TouchableOpacity>
                <TouchableOpacity onPress= {() => props.navigation.navigate('Survey', {name: 'Branch Survey'})}>
                    <SurveyCard>
                        <View style= {styles.textContainer}>
                            <Text style= {styles.textStyle}>
                            Branch Survey
                            </Text>
                            <View style= {styles.flexContainer}>
                                <Text style= {styles.textStyle2}>
                                    ENTER SURVEY
                                </Text>
                                
                            </View>
                        </View>
                    </SurveyCard>
                </TouchableOpacity>
                <TouchableOpacity  onPress= {() => props.navigation.navigate('Survey', {name: 'Staff Survey'})}>
                    <SurveyCard>
                        <View style= {styles.textContainer}>
                            <Text style= {styles.textStyle}>
                            Staff Survey
                            </Text>
                            <View style= {styles.flexContainer}>
                                <Text style= {styles.textStyle2}>
                                    ENTER SURVEY
                                </Text>
                                
                            </View>
                        </View>
                    </SurveyCard>
                </TouchableOpacity>
                <TouchableOpacity  onPress= {() => props.navigation.navigate('Survey', {name: 'Customer Experience Survey'})}>
                    <SurveyCard>
                        <View style= {styles.textContainer}>
                            <Text style= {styles.textStyle}>
                            Customer Experience Survey
                            </Text>
                            <View style= {styles.flexContainer}>
                                <Text style= {styles.textStyle2}>
                                    ENTER SURVEY
                                </Text>
                                
                            </View>
                        </View>
                    </SurveyCard>
                </TouchableOpacity>
            </View>
         
        </ScrollView>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,

    },
    imageStyle: {
        width: '100%',
        height: Dimensions.get('window').height/3,
        resizeMode: 'contain'
    },
    textStyle: {
        color: 'white',
        fontSize: 16,
        fontWeight: 'bold'
    },
    textStyle2: {
        color: 'white',
        fontSize: 13
    },
    flexContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginVertical: 20
    },
    lowerContainer: {
        marginHorizontal: 30,
        marginVertical: 20,
        display: 'flex',
        flexDirection: 'row',
        flexWrap: 'wrap'
    
    },
    textContainer: {
        width: '60%',
        marginVertical: 20,
        marginHorizontal: 20
    }
});

export default Home